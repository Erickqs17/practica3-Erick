
package newpackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

interface MetodoPago {
    void pagar(double monto);
}

class PagoEfectivo implements MetodoPago {
    public void pagar(double monto) {
        System.out.println("[Bridge] Pago en efectivo de $" + monto);
    }
}

class PagoTarjeta implements MetodoPago {
    public void pagar(double monto) {
        System.out.println("[Bridge] Pago con tarjeta de $" + monto);
    }
}

class PedidoBridge {
    private final MetodoPago metodoPago;
    private final double monto;

    public PedidoBridge(double monto, MetodoPago metodoPago) {
        this.monto = monto;
        this.metodoPago = metodoPago;
    }

    public void procesar() {
        System.out.println("[Bridge] Procesando pedido de $" + monto);
        metodoPago.pagar(monto);
    }
}

// --- OBSERVER ---
interface Observer {
    void actualizar(String mensaje);
}

interface Subject {
    void registrarObservador(Observer o);
    void eliminarObservador(Observer o);
    void notificar(String mensaje);
}

class Usuario implements Observer {
    private final String nombre;

    public Usuario(String nombre) {
        this.nombre = nombre;
    }

    public void actualizar(String mensaje) {
        System.out.println("[Observer][" + nombre + "] " + mensaje);
    }
}

class Notificador implements Subject {
    private final List<Observer> observadores = new ArrayList<>();

    public void registrarObservador(Observer o) {
        observadores.add(o);
    }

    public void eliminarObservador(Observer o) {
        observadores.remove(o);
    }

    public void notificar(String mensaje) {
        for (Observer o : observadores) {
            o.actualizar(mensaje);
        }
    }
}

// --- COMMAND ---
interface Command {
    void ejecutar();
    void deshacer();
}

class PedidoVenta {
    private final String producto;
    private final double monto;
    private boolean registrado = false;

    public PedidoVenta(String producto, double monto) {
        this.producto = producto;
        this.monto = monto;
    }

    public void registrar() {
        registrado = true;
        System.out.println("[Model] Pedido registrado: " + producto + " ($" + monto + ")");
    }

    public void cancelar() {
        registrado = false;
        System.out.println("[Model] Pedido cancelado: " + producto);
    }

    public boolean isRegistrado() {
        return registrado;
    }
}

class RegistrarPedidoCommand implements Command {
    private final PedidoVenta pedido;

    public RegistrarPedidoCommand(PedidoVenta pedido) {
        this.pedido = pedido;
    }

    public void ejecutar() {
        pedido.registrar();
    }

    public void deshacer() {
        pedido.cancelar();
    }
}

class CancelarPedidoCommand implements Command {
    private final PedidoVenta pedido;

    public CancelarPedidoCommand(PedidoVenta pedido) {
        this.pedido = pedido;
    }

    public void ejecutar() {
        pedido.cancelar();
    }

    public void deshacer() {
        pedido.registrar();
    }
}

class ControlPedidos {
    private Command comandoActual;
    private final Stack<Command> historial = new Stack<>();

    public void setCommand(Command comando) {
        this.comandoActual = comando;
    }

    public void ejecutarComando() {
        if (comandoActual != null) {
            comandoActual.ejecutar();
            historial.push(comandoActual);
        }
    }

    public void deshacer() {
        if (!historial.isEmpty()) {
            historial.pop().deshacer();
        }
    }
}

// --- MAIN ---
public class Main {
    public static void main(String[] args) {
        // BRIDGE
        MetodoPago tarjeta = new PagoTarjeta();
        PedidoBridge pedido = new PedidoBridge(120.5, tarjeta);
        pedido.procesar();

        // OBSERVER
        Notificador notificador = new Notificador();
        Usuario cocina = new Usuario("Cocina");
        Usuario gerente = new Usuario("Gerente");
        notificador.registrarObservador(cocina);
        notificador.registrarObservador(gerente);

        // COMMAND
        PedidoVenta pv = new PedidoVenta("Hamburguesa", 50.0);
        RegistrarPedidoCommand regCmd = new RegistrarPedidoCommand(pv);
        CancelarPedidoCommand cancelCmd = new CancelarPedidoCommand(pv);
        ControlPedidos control = new ControlPedidos();

        control.setCommand(regCmd);
        control.ejecutarComando();
        notificador.notificar("Nuevo pedido registrado: Hamburguesa");

        control.setCommand(cancelCmd);
        control.ejecutarComando();
        notificador.notificar("Pedido cancelado: Hamburguesa");

        control.deshacer();
        notificador.notificar("Pedido reactivado: Hamburguesa");
    }
}
